<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="multikart">
    <meta name="keywords" content="multikart">
    <meta name="author" content="multikart">
    <title>Yolo Bus</title>
    <!--Google font-->
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
    <!-- Icons -->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/fontawesome.css') ?>">
    <!--Slick slider css-->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/slick.css')?>">
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/slick-theme.css')?>">
    <!-- Animate icon -->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/animate.css')?>">
    <!-- Themify icon -->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/themify-icons.css')?>">
    <!-- Bootstrap css -->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/bootstrap.css')?>">

    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/view.css')?>">
    
    <!-- Theme css -->
    <link rel="stylesheet" type="text/css" href="<? echo base_url('assets/css/color2.css')?>" media="screen" id="color">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">


    

<style>
    .navbar{
        background-color: #3fdda7 !important;
    }
    .navbar-light .navbar-brand{
        color: white !important;
    }
    .mobile-wishlist a{
        color: white !important;
    }
.collection-banner .contain-banner.banner-3 h2{font-size:17px !important;}
.upldbtn{  }
@media (max-width: 480px){.upldbtn {width:250px;}}</style>

</head>
